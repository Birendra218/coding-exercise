# Read Me First
# Add stock to watch:

http://localhost:8080/stocks/INTC

# web socket URL
- ws://localhost:8080/stocks-refresh

